<template>
  <el-button type="primary">Save</el-button>
</template>
<script>
  export default{
    name: 'Save'
  }
</script>
